package com.naver.www.diary;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.widget.ArrayAdapter;
import android.widget.ListView;

public class SettingAp extends AppCompatActivity{

     // 정적 List
    static final String[] LIST_MENU = {"비밀번호 설정", "기본 테마", "초기화", "피드백(리뷰)", "어플리케이션 정보"} ;
    ListView setting_List;

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_settingap);

        setting_List = (ListView) findViewById(R.id.setting_List) ; // 셋팅 리스트뷰 지정

        ArrayAdapter adapter = new ArrayAdapter(this,   android.R.layout.simple_list_item_1, LIST_MENU);
        setting_List.setAdapter(adapter) ; // 어댑터 내용 적용


    }
}
