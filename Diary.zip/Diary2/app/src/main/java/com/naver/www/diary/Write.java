package com.naver.www.diary;


import android.app.Dialog;
import android.content.DialogInterface;
import android.graphics.Color;
import android.os.Bundle;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.RatingBar;
import android.widget.TextView;
import android.widget.Toast;

import java.io.File;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Locale;


public class Write extends AppCompatActivity {

    Button xButtonLoad, load_btn;
    android.widget.LinearLayout popupLayout; // 리스트 뷰 팝업
    ListView load_List;
    String select = "x"; // 리스트뷰 아이템 선택
    RatingBar ratingBar; // 행복지수

    EditText mMemoEdit1 = null; // 제목
    EditText mMemoEdit2 = null; // 내용
    TextView mMemoEdit3 = null; // 날짜

    TextFileManager mTextFileManager = new TextFileManager(this); // 파일시스템 관리 하려고 객체생성



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_write);

        ratingBar = findViewById(R.id.ratingBar); // 레이팅바 셋팅

        final ArrayList<String> loadListItem = new ArrayList<String>(); // 빈 데이터 리스트 생성
        int forI = Integer.parseInt(mTextFileManager.setload());

        for(int i = 1; i <= forI;i++){ // 어레이 리스트에 넣어줌
            try{
                String u = mTextFileManager.uLoad(i);
                String title = mTextFileManager.titleLoad(i);
                if(!(title.equals(""))){ // 빈 문서는 의미가 없으니 걸러줌
                    loadListItem.add(u + ") " + title);
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
        }

        // 리스트뷰에 사용할 어댑터 객체 생성 simple_list_item_single_choice
        ArrayAdapter adapter = new ArrayAdapter(this,   android.R.layout.simple_list_item_single_choice, loadListItem);

        load_List = (ListView) findViewById(R.id.load_List) ; // 로드 리스트뷰 지정
        load_List.setAdapter(adapter) ; // 어댑터 내용 적용

        load_List.setOnItemClickListener(new AdapterView.OnItemClickListener() { // 리스트뷰 아이템 클릭 리스너
            @Override
            public void onItemClick(AdapterView parent, View v, int position, long id) {
                // 클릭한 값 가져오기
                select = (String) parent.getItemAtPosition(position) ;
                System.out.println(select); // 0부터 가져옴
                // 이 값을 이용하여 불러오기 구현
            }
        }) ;


        popupLayout = findViewById(R.id.popup_layer); // loadlist 팝업
        load_btn = (Button) findViewById(R.id.load_btn);

        mMemoEdit1 = (EditText) findViewById(R.id.memo_edit1); // 제목
        mMemoEdit2 = (EditText) findViewById(R.id.memo_edit2); // 내용
        mMemoEdit3 = (TextView) findViewById(R.id.memo_edit3); // 날짜

        SimpleDateFormat mSimpleDateFormat = new SimpleDateFormat ( "yyyy.MM.dd HH:mm", Locale.KOREA ); //현재시간 셋팅 - 년.월.일 시:분
        Date currentTime = new Date ();
        String openTime = mSimpleDateFormat.format ( currentTime );
        mMemoEdit3.setText(openTime);




        load_btn.setOnClickListener(new View.OnClickListener() { // 로드 팝업 열기
            @Override
            public void onClick(View v) {
                popupLayout.setVisibility(View.VISIBLE);
            }
        });

        xButtonLoad = findViewById(R.id.xButtonLoad); // 로드 팝업 닫기
        xButtonLoad.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                popupLayout.setVisibility(View.GONE);
            }
        });


    }

    public void onClick(View v) {
        switch (v.getId()) { // 불러오기 클릭
            case R.id.load_btn_sub: { // ************************** 개발중
/*                String memoData1 = mTextFileManager.titleLoad(18);
                String memoData2 = mTextFileManager.txtLoad(18);
                String memoData3 = mTextFileManager.dateLoad(18);
                mMemoEdit1.setText(memoData1);
                mMemoEdit2.setText(memoData2);
                mMemoEdit3.setText(memoData3);*/
                Toast.makeText(this, "불러오기 완료(아직 개발중)", Toast.LENGTH_LONG).show();
                break;
            }

            case R.id.save_btn: { // 저장 버튼 클릭시

                SimpleDateFormat mSimpleDateFormat = new SimpleDateFormat ( "yyyy.MM.dd HH:mm", Locale.KOREA ); //현재 날짜
                Date currentTime = new Date ();
                String mTime = mSimpleDateFormat.format ( currentTime ); // 시간 임시 저장

                String memoData1 = mMemoEdit1.getText().toString(); //제목
                String memoData2 = mMemoEdit2.getText().toString(); //내용

                AlertDialog.Builder dialog = new AlertDialog.Builder(Write.this); // 알림창 객체 생성해서 준비

                if(memoData1.equals("") || memoData1 == null) { // 제목에 아무것도 없거나 null일 경우

                    dialog.setMessage("제목을 써주세요!");
                    dialog.setNegativeButton("네", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialogInterface, int i) {
                        }
                    });
                    dialog.show(); // 셋팅한 다이얼로그 출력

                } else if(memoData2.equals("") || memoData2 == null) { // 내용에 아무것도 없거나 null일 경우
                    dialog.setMessage("내용을 써주세요!");
                    dialog.setNegativeButton("네", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialogInterface, int i) {
                        }
                    });
                    dialog.show(); // 셋팅한 다이얼로그 출력
                } else { // 제목과 내용이 정상적으로 썻다면 저장 작업 수행
                    mTextFileManager.titleSave(memoData1); // 제목
                    mTextFileManager.txtSave(memoData2); // 내용
                    mTextFileManager.dateSave(mTime); // 날짜
                    mTextFileManager.uSave(Integer.toString(mTextFileManager.getIntnCheck())); // 고유코드 저장 IntnCheck 기본 작업은 titleSave에서 함
                    mTextFileManager.ratingSave(Float.toString(ratingBar.getRating())); // rating은 실수이므로 문자열로 변환 후 저장
                    mMemoEdit1.setText(""); // 저장 했으니 초기화
                    mMemoEdit2.setText("");


                    Toast.makeText(this, mTextFileManager.getIntnCheck() + "번째 저장 완료", Toast.LENGTH_LONG).show();
                }
                break;
            }


            case R.id.delete_btn: {  // 삭제 클릭
                                       //********************** 개발중
                AlertDialog.Builder dialog = new AlertDialog.Builder(Write.this); // 알림창 객체 생성해서 준비
                dialog.setTitle("경고!"); // 알림창 제목 설정
                dialog.setMessage("삭제한 일기는 복구할 수 없습니다. \n그래도 삭제 하시겠습니까?"); //알림창 내용 설정

                dialog.setNegativeButton("아니요", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        Toast.makeText(Write.this, "취소했습니다.", Toast.LENGTH_LONG).show();
                    }
                });

                dialog.setPositiveButton("네", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        /*
                        mTextFileManager.delete();*/ // 개발중
                        mMemoEdit1.setText(""); // 삭제했으니 내용 비움
                        mMemoEdit2.setText("");

                        Toast.makeText(Write.this, "삭제 완료(아직 개발중)", Toast.LENGTH_LONG).show();
                        // dialog 안에서 Toast는 context 앞에 클래스를 붙여줘야 함
                    }
                });

                dialog.show();

            }
        }

    }
}