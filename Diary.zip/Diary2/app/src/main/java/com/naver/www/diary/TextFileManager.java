package com.naver.www.diary;


import android.content.Context;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;

public class TextFileManager {

    private static String FILE_title = "title.txt"; // 제목
    private static String FILE_txt = "txt.txt"; // 내용
    private static String FILE_date = "date.txt"; // 날짜
    private static String FILE_u = "u.txt"; // 고유값
    private static String FILE_rating = "rating.txt"; // 별점
    private static String FILE_n = "n.txt"; // 전체 공유 (수)
    private int intnCheck;
    // 메모 내용을 저장할 파일 이름
    Context mContext = null;

    public int getIntnCheck() {
        return intnCheck;
    }

    public TextFileManager(Context context) {
        mContext = context;


    }

    public void titleSave(String strData) { //제목 저장
        //static 이용 이름 정하기
        String nCheck = this.setload(); // count용 txt 로드 title만 적용
        String nSave;
        intnCheck = Integer.parseInt(nCheck); // 이 변수는 내용, 레이팅, 날짜 등에도 활용함(코드 절약)
        intnCheck++; // 기본값 0 첫글 이라는 것을 표시하기 위해 +1 하고 시작
        this.setsave(Integer.toString(intnCheck)); // 다음 저장파일을 위해 저장 n.txt

        FILE_title = "title" + intnCheck + ".txt"; // 제목
        FileOutputStream fosMemo = null;

        if (strData == null || strData.equals("")) {
            return;
        }
        try {
            // 파일에 데이터를 쓰기 위해서 output 스트림 생성 후 저장
            fosMemo = mContext.openFileOutput(FILE_title, Context.MODE_PRIVATE);
            fosMemo.write(strData.getBytes());
            fosMemo.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void txtSave(String strData) { //내용 저장
        FILE_txt = "txt" + intnCheck + ".txt"; // 내용
        FileOutputStream fosMemo = null;

        if (strData == null || strData.equals("")) {
            return;
        }
        try {
            // 파일에 데이터를 쓰기 위해서 output 스트림 생성 후 저장
            fosMemo = mContext.openFileOutput(FILE_txt, Context.MODE_PRIVATE);
            fosMemo.write(strData.getBytes());
            fosMemo.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void dateSave(String strData) { //날짜 저장
        FILE_date = "date" + intnCheck + ".txt"; // 내용
        FileOutputStream fosMemo = null;

        if (strData == null || strData.equals("")) {
            return;
        }
        try {
            // 파일에 데이터를 쓰기 위해서 output 스트림 생성 후 저장
            fosMemo = mContext.openFileOutput(FILE_date, Context.MODE_PRIVATE);
            fosMemo.write(strData.getBytes());
            fosMemo.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    public void ratingSave(String strData) { //레이팅 저장
        FILE_rating = "rating" + intnCheck + ".txt"; // 내용
        FileOutputStream fosMemo = null;

        if (strData == null || strData.equals("")) {
            return;
        }
        try {
            // 파일에 데이터를 쓰기 위해서 output 스트림 생성 후 저장
            fosMemo = mContext.openFileOutput(FILE_rating, Context.MODE_PRIVATE);
            fosMemo.write(strData.getBytes());
            fosMemo.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    public void uSave(String strData) { //고유값 저장
        FILE_u = "u" + intnCheck + ".txt"; // 내용
        FileOutputStream fosMemo = null;

        if (strData == null || strData.equals("")) {
            return;
        }
        try {
            // 파일에 데이터를 쓰기 위해서 output 스트림 생성 후 저장
            fosMemo = mContext.openFileOutput(FILE_u, Context.MODE_PRIVATE);
            fosMemo.write(strData.getBytes());
            fosMemo.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public String titleLoad(int num) { // 제목 불러오기 num은 몇번째
        try {
            FILE_title = "title" + num + ".txt";
            // 파일에서 데이터를 읽기 위해서 input 스트림 생성
            FileInputStream fisMemo = mContext.openFileInput(FILE_title);
            // 데이터를 읽어 온 뒤, String 타입 객체로 반환
            byte[] memoData = new byte[fisMemo.available()];
            while (fisMemo.read(memoData) != -1) {
            }
            return new String(memoData);
        } catch (IOException e) {
        }
        return "";
    }
    public String txtLoad(int num) { // 내용 불러오기 num은 몇번째
        try {
            FILE_txt = "txt" + num + ".txt";
            // 파일에서 데이터를 읽기 위해서 input 스트림 생성
            FileInputStream fisMemo = mContext.openFileInput(FILE_txt);
            // 데이터를 읽어 온 뒤, String 타입 객체로 반환
            byte[] memoData = new byte[fisMemo.available()];
            while (fisMemo.read(memoData) != -1) {
            }
            return new String(memoData);
        } catch (IOException e) {
        }
        return "";
    }
    public String dateLoad(int num) { // 날짜 불러오기 num은 몇번째
        try {
            FILE_date = "date" + num + ".txt";
            // 파일에서 데이터를 읽기 위해서 input 스트림 생성
            FileInputStream fisMemo = mContext.openFileInput(FILE_date);
            // 데이터를 읽어 온 뒤, String 타입 객체로 반환
            byte[] memoData = new byte[fisMemo.available()];
            while (fisMemo.read(memoData) != -1) {
            }
            return new String(memoData);
        } catch (IOException e) {
        }
        return "";
    }
    public String uLoad(int num) { // 고유값 불러오기 num은 몇번째
        try {
            FILE_u = "u" + num + ".txt";
            // 파일에서 데이터를 읽기 위해서 input 스트림 생성
            FileInputStream fisMemo = mContext.openFileInput(FILE_u);
            // 데이터를 읽어 온 뒤, String 타입 객체로 반환
            byte[] memoData = new byte[fisMemo.available()];
            while (fisMemo.read(memoData) != -1) {
            }
            return new String(memoData);
        } catch (IOException e) {
        }
        return "";
    }

    // 저장된 메모를 삭제하는 함수
    public void delete() {
        mContext.deleteFile(FILE_title);
    }

    public void setn(String strData) { // 첫 일기 생성 n.txt

        FileOutputStream fosMemo = null;

        if (strData == null || strData.equals("")) {
            return;
        }

        try {
            // 파일에 데이터를 쓰기 위해서 output 스트림 생성
            fosMemo = mContext.openFileOutput(FILE_n, Context.MODE_PRIVATE);
            // 파일에 메모 적기
            fosMemo.write(strData.getBytes());
            fosMemo.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public String setload() { // static 이용 저장용
        try {
            // 파일에서 데이터를 읽기 위해서 input 스트림 생성
            FileInputStream fisMemo = mContext.openFileInput(FILE_n);

            // 데이터를 읽어 온 뒤, String 타입 객체로 반환
            byte[] memoData = new byte[fisMemo.available()];
            while (fisMemo.read(memoData) != -1) {
            }

            return new String(memoData);
        } catch (IOException e) {
        }

        return "";
    }


    public void setsave(String strData) { // static 저장

        FileOutputStream fosMemo = null;

        if (strData == null || strData.equals("")) {
            return;
        }

        try {
            // 파일에 데이터를 쓰기 위해서 output 스트림 생성
            fosMemo = mContext.openFileOutput(FILE_n, Context.MODE_PRIVATE);
            // 파일에 메모 적기
            fosMemo.write(strData.getBytes());
            fosMemo.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }


}