package com.naver.www.diary;

import android.content.DialogInterface;
import android.os.Bundle;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.widget.ImageButton;
import android.content.Intent;

import android.view.View;
import android.widget.Button;

import android.widget.RatingBar;
import android.widget.Toast;

import java.io.File;

public class Diary extends AppCompatActivity {
    ImageButton menu1, menu2, menu3, menu4;
    Button xButton;
    android.widget.LinearLayout popupLayout;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_diary);

        menu1 = findViewById(R.id.menu1);
        menu2 = findViewById(R.id.menu2);
        menu3 = findViewById(R.id.menu3);
        menu4 = findViewById(R.id.menu4);
        popupLayout = findViewById(R.id.popup_layer);

        TextFileManager mTextFileManager = new TextFileManager(this);

        File check = new File("/data/data/com.naver.www.diary/files/n.txt");
        boolean isExists = check.exists();
        if(!isExists) { // 첫일기를 쓴다면 누적해서 저장하기 위한 n.txt 파일 생성
            String memoData = "0";
            mTextFileManager.setn(memoData); // 최초 저장으로 n.txt 생성
            // n.txt 는 몇번째의 일기를 쓰고있는지 기록하기 위함.

            Toast.makeText(this, "첫 일기를 쓰시는 군요!?", Toast.LENGTH_LONG).show(); // 테스트용 메세지
        } else {

        }

        menu1.setOnClickListener(new android.view.View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Intent Write = new Intent(Diary.this, Write.class);
                startActivity(Write);
            }
        });

        menu2.setOnClickListener(new android.view.View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Toast.makeText(getApplicationContext(),"개발중입니다....",Toast.LENGTH_SHORT).show();
                Intent calendar = new Intent(Diary.this, Calendar.class);
                startActivity(calendar);
            }
        });

                menu3.setOnClickListener(new android.view.View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(getApplicationContext(),"개발중입니다....",Toast.LENGTH_SHORT).show();
                Intent settingAp = new Intent(Diary.this, SettingAp.class);
                startActivity(settingAp);
            }
        });

                 menu4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                popupLayout.setVisibility(View.VISIBLE);
            }
        });

        xButton = findViewById(R.id.xButton);
        xButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                popupLayout.setVisibility(View.GONE);
            }
        });
    }

}
