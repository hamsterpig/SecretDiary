package com.naver.www.diary;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import android.widget.TextView;
import android.widget.Toast;

import java.io.File;

public class MainActivity extends AppCompatActivity {
    TextView lock1, lock2, lock3, lock4;

/*
    Button btnNum0, btnNum1, btnNum2, btnNum3,btnNum4, btnNum5, btnNum6, btnNum7, btnNum8, btnNum9;
*/
    Button[] numButtons = new Button[10];
    Button btnBack;
    Integer[] numBtnIDS={R.id.btnNum0, R.id.btnNum1, R.id.btnNum2, R.id.btnNum3, R.id.btnNum4,
            R.id.btnNum5, R.id.btnNum6, R.id.btnNum7, R.id.btnNum8, R.id.btnNum9};
    int p1, p2, p3, p4;
    int lnum = 1;





    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

/*        TextFileManager mTextFileManager = new TextFileManager(this);
        File n = new File("/data/data/com.naver.www.diary/files/n.txt");
        n.delete(); //file Delete*/

/*        for(int i = 1; i <= Integer.parseInt(mTextFileManager.setload()); i++){
            try{
                File f = new File("/data/data/com.naver.www.diary/files/n.txt");
                f.delete(); //file Delete
            } catch (Exception e){
                e.getMessage();
            }
        }*/




        lock1 = findViewById(R.id.lock1);
        lock2 = findViewById(R.id.lock2);
        lock3 = findViewById(R.id.lock3);
        lock4 = findViewById(R.id.lock4);
        btnBack = findViewById(R.id.btnBack);



        for (int i = 0; i< numBtnIDS.length; i++){
            numButtons[i] = (Button)findViewById(numBtnIDS[i]);
        }

        for (int i = 0; i< numBtnIDS.length; i++){

            final int index;
            index = i;

            numButtons[index].setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    if(lnum == 1){
                        lock1.setText(numButtons[index].getText());
                        p1 = Integer.parseInt(numButtons[index].getText().toString());
                        lnum ++;
                    } else if(lnum == 2) {
                        lock2.setText(numButtons[index].getText());
                        p2 = Integer.parseInt(numButtons[index].getText().toString());
                        lnum ++;
                    } else if(lnum == 3) {
                        lock3.setText(numButtons[index].getText());
                        p3 = Integer.parseInt(numButtons[index].getText().toString());
                        lnum ++;
                    } else if(lnum == 4) {
                        lock4.setText(numButtons[index].getText());
                        p4 = Integer.parseInt(numButtons[index].getText().toString());

                        if(p1 == 1 && p2 == 2 && p3 == 3 && p4 == 3)
                        {
                            Toast.makeText(getApplicationContext(),"인증 완료!",Toast.LENGTH_SHORT).show();
                            lnum = 1;
                            lock1.setText(null);
                            lock2.setText(null);
                            lock3.setText(null);
                            lock4.setText(null);
                            Intent LockPass = new Intent(MainActivity.this, Diary.class);
                            startActivity(LockPass);
                        } else {
                            Toast.makeText(getApplicationContext(),"비밀번호가 틀렸습니다.",Toast.LENGTH_SHORT).show();
                            lnum = 1;
                            lock1.setText(null);
                            lock2.setText(null);
                            lock3.setText(null);
                            lock4.setText(null);
                        }
                    } else {
                        lnum = 1;
                    }

                }
            });
        } // for

        btnBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
            switch (lnum){
                case 4:
                    lock3.setText(null);
                    lnum --;
                    break;
                case 3:
                    lock2.setText(null);
                    lnum --;
                    break;
                case 2:
                    lock1.setText(null);
                    lnum --;
                    break;
            }


            }
        });




        }
    }

